import { Component, ElementRef, ViewChild  } from '@angular/core';
// import * as html2canvas from 'html2canvas';
declare let html2canvas: any;
import blasterjs from "biojs-vis-blasterjs";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  
  name = 'html2canvas capture in Angular';

  capturedImage;
  constructor() {
   
  }
  

  clickme() {

    let instance = new blasterjs({
      input: "blastinput",
      multipleAlignments: "blast-multiple-alignments",
      alignmentsTable: "blast-alignments-table",
      singleAlignment: "blast-single-alignment"
   });

    
  }
}
